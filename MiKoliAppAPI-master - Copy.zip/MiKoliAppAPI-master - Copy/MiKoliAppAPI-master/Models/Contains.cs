﻿namespace MiKoliAPI.Models
{
    public class Contains
    {
        public int ContainID { get; set; }
        public int MainMenuID { get; set; }
        public int ParameterID { get; set; }
        public string Title { get; set; }
        public string MenuOrder { get; set; }
        public string EnglishHead { get; set; }
        public string Cont { get; set; }
        public string Cont1 { get; set; }
        public string Cont2 { get; set; }
        public string Cont3 { get; set; }
        public string Cont4 { get; set; }
        public string Cont5 { get; set; }
        public string Cont6 { get; set; }
        public string Cont7 { get; set; }
        public string Cont8 { get; set; }
        public string Cont9 { get; set; }
        public string Cont10 { get; set; }
        public string ContainData { get; set; }
        public string Testdt { get; set; }
        public string PageImage { get; set; }
    }
}
