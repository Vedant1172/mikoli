﻿namespace MiKoliAPI.Models
{
    public class MainMenu
    {    
        public int MainMenuID { get; set; }
        public string Title { get; set; }
        public string Controller { get; set; }
        public string Method { get; set; }
        public int ParameterID { get; set; }
        
    }
}
